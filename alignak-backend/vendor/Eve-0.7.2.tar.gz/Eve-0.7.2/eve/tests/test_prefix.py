# -*- coding: utf-8 -*-

URL_PREFIX = 'prefix'
DOMAIN = {'contacts': {}}
