# -*- coding: utf-8 -*-

# this is just a helper file which we are going
# to try to load with environmental variable in
# test_existing_env_config() test case

DOMAIN = {'env_domain': {}}
